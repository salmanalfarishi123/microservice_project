package com.example.CardTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardTestApplication.class, args);
	}

}
