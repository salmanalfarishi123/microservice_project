package com.example.CardTest.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.CardTest.model.CardsModel;

public interface CardsRepository extends CrudRepository<CardsModel,Long>{
	
	List <CardsModel> findByCustomerId(int customerId);

}

