package com.example.CardTest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.CardTest.model.CardsModel;
import com.example.CardTest.model.Customer;
import com.example.CardTest.repository.CardsRepository;

@RestController
public class CardsController {

	@Autowired
	private CardsRepository cardsRepository;
	
	@PostMapping("/cards")
	public List<CardsModel>getCardDetails(@RequestBody Customer customer){
		List<CardsModel> cards = cardsRepository.findByCustomerId(customer.getCustomerId());
		return cards;
	}
}
