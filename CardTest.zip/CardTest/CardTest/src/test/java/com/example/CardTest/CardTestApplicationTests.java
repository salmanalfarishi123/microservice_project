package com.example.CardTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
