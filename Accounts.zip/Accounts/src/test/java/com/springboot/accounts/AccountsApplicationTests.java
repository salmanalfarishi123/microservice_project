package com.springboot.accounts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = AccountsApplication.class)
class AccountsApplicationTests {

	@Test
	void contextLoads() {
	}

}
