                                                                   package com.springboot.accounts.repository;

import org.springframework.data.repository.CrudRepository;

import com.springboot.accounts.model.AccountModel;

public interface AccountRepository extends CrudRepository<AccountModel,Long>{

	AccountModel findByCustomerId(int customerId);
	
	
}
