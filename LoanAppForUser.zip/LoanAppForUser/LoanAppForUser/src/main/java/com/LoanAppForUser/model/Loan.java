package com.LoanAppForUser.model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name = "loans")
public class Loan {

	
	 @Id
	 @Column(name = "loan_number")
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 private int loanNumber;
	 
	 @Column(name = "customer_id")
	 private int custmerId;
	 
	 @Column(name = "loan_type")
	 private String loanType;
	 
	 @Column(name = "loan_amount")
	 private int loanAmount;
	 
	 @Column(name = "loan_end_date")
	 private Date loanEndDate;
	 
	 
	 public int getLoanNumber() {
		return loanNumber;
	}
	public void setLoanNumber(int loanNumber) {
		this.loanNumber = loanNumber;
	}
	public int getCustmerId() {
		return custmerId;
	}
	public void setCustmerId(int custmerId) {
		this.custmerId = custmerId;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public int getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(int loanAmount) {
		this.loanAmount = loanAmount;
	}
	public Date getLoanEndDate() {
		return loanEndDate;
	}
	public void setLoanEndDate(Date loanEndDate) {
		this.loanEndDate = loanEndDate;
	}
	 
	 
}
