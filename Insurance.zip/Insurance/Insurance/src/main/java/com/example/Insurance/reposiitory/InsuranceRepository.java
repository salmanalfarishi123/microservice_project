package com.example.Insurance.reposiitory;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.Insurance.model.InsuranceModel;



public interface InsuranceRepository extends CrudRepository<InsuranceModel,Long>{
	
	List <InsuranceModel> findByCustomerId(int customerId);

}

