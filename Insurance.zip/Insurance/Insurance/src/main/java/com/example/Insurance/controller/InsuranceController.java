package com.example.Insurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Insurance.model.Customer;
import com.example.Insurance.model.InsuranceModel;
import com.example.Insurance.reposiitory.InsuranceRepository;



public class InsuranceController {

	@Autowired
	private InsuranceRepository insuranceRepository;
	
	@PostMapping("/call")
	public List<InsuranceModel>getInsuranceDetails(@RequestBody Customer customer){
		List<InsuranceModel> insurance = insuranceRepository.findByCustomerId(customer.getCustomerId());
		return insurance;
	}
}
