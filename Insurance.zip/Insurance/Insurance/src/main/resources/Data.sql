DROP TABLE IF EXISTS insurance;

CREATE TABLE `insurance` (
`customer_id` int AUTO_INCREMENT PRIMARY KEY,
`insurance_type` varchar(100) NOT NULL,
`insured_amount` int NOT NULL,
`insurance_end_date` date DEFAULT NULL
);






INSERT INTO insurance ( `insurance_type`,`insured_amount`,`insurance_end_date`) 
VALUES ( 'VEHICLE INSURANCE', 99000, CURDATE()+365);



